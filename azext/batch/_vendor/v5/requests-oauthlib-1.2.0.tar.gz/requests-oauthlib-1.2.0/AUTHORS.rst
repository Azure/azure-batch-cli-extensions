Requests-oauthlib is written and maintained by Kenneth Reitz and various
contributors:

Development Lead
----------------

- Kenneth Reitz <me@kennethreitz.com>

Patches and Suggestions
-----------------------

- Cory Benfield <cory@lukasa.co.uk>
- Ib Lundgren <ib.lundgren@gmail.com>
- Devin Sevilla <dasevilla@gmail.com>
- Imad Mouhtassem <mouhtasi@gmail.com>
- Johan Euphrosine <proppy@google.com>
- Johannes Spielmann <js@shezi.de>
- Martin Trigaux <me@mart-e.be>
- Matt McClure <matt.mcclure@mapmyfitness.com>
- Mikhail Sobolev <mss@mawhrin.net>
- Paul Bonser <misterpib@gmail.com>
- Vinay Raikar <rockraikar@gmail.com>
- kracekumar <me@kracekumar.com>
- David Baumgold <david@davidbaumgold.com>
