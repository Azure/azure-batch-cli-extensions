.. :changelog:

Template Release History
===================

2018-12-01
------------------
* Add functionality to have supported template versions to SDK Extensions
* Add functionality to template resource files to support expanded resource file properties

2016-12-01
------------------
* Initial Release