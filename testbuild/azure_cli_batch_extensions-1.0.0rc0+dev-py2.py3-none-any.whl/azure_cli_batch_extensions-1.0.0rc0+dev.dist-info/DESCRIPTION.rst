Microsoft Azure Batch CLI Extensions for Windows, Mac and Linux


